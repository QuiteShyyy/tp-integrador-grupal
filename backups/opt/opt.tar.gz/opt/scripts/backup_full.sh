#!/bin/bash

# Backup Script - backup_full.sh
# Description: Performs backups with YYYYMMDD date format
# Usage: ./backup_full.sh -source /path/source -destination /path/destination [-help]

# Variables
DATE=$(date +%Y%m%d)
SOURCE=""
DESTINATION=""
HELP=false

# Help function
show_help() {
    echo "========================================"
    echo "Backup Script - backup_full.sh"
    echo "========================================"
    echo ""
    echo "Usage: $0 -source SOURCE -destination DESTINATION"
    echo ""
    echo "Options:"
    echo "  -source ROUTE         Directory to backup (required)"
    echo "  -destination ROUTE    Destination directory (required)"
    echo "  -help                 Show this help"
    echo ""
    echo "Example:"
    echo "  $0 -source /var/logs -destination /backup_dir"
    echo "  Result: /backup_dir/logs_bkp_20240515.tar.gz"
    echo ""
    echo "========================================"
}

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -source)
            SOURCE="$2"
            shift 2
            ;;
        -destination)
            DESTINATION="$2"
            shift 2
            ;;
        -help)
            show_help
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            echo "Use -help to see help"
            exit 1
            ;;
    esac
done

# Validate arguments
if [ -z "$SOURCE" ] || [ -z "$DESTINATION" ]; then
    echo "Error: -source and -destination are required"
    echo "Use -help to see help"
    exit 1
fi

# Validate that source exists
if [ ! -d "$SOURCE" ]; then
    echo "Error: Source directory '$SOURCE' does not exist"
    exit 1
fi

# Validate that destination is accessible (and is a directory)
if [ ! -d "$DESTINATION" ]; then
    echo "Error: Destination directory '$DESTINATION' does not exist"
    exit 1
fi

# Check filesystem availability
if ! mountpoint -q "$SOURCE"; then
    echo "Warning: Source directory '$SOURCE' may not be mounted"
fi

if ! mountpoint -q "$DESTINATION"; then
    echo "Warning: Destination directory '$DESTINATION' may not be mounted"
fi

# Extract directory name for the backup file
DIR_NAME=$(basename "$SOURCE")

# Create backup filename
BACKUP_FILE="${DIR_NAME}_bkp_${DATE}.tar.gz"
FULL_PATH="$DESTINATION/$BACKUP_FILE"

echo "========================================"
echo "Starting Backup"
echo "========================================"
echo "Source:      $SOURCE"
echo "Destination: $DESTINATION"
echo "Filename:    $BACKUP_FILE"
echo "Date:        $DATE"
echo "========================================"

# Execute backup
if tar -czf "$FULL_PATH" -C "$(dirname "$SOURCE")" "$(basename "$SOURCE")" 2>/dev/null; then
    SIZE=$(du -h "$FULL_PATH" | cut -f1)
    echo "âœ“ Backup completed successfully"
    echo "âœ“ File: $FULL_PATH"
    echo "âœ“ Size:  $SIZE"
    echo "========================================"
    exit 0
else
    echo "âœ— Error: Could not create backup"
    echo "========================================"
    exit 1
fi