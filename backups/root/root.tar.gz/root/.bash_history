ping -c 3 8.8.8.8
vi /etc/ssh/sshd_config
vi /etc/ssh/sshd_config
systemctl restart ssh
vi /etc/ssh/sshd_config
systemctl restart ssh
vi /etc/ssh/sshd_config
systemctl restart ssh
ls -la /root/
rm -rf /root/
rm -rf /root/*
ls -la /root/
ls -la /root
cp /etc/skel/.* /root/ 2>/dev/null 
ls -la /root
ls -la /root/
chown -R root:root /root
mmkdir -p /root
mkdir -p /root
cp /etc/skel/.* /root/ 2>/dev/null 
cp /etc/skel/.bashrc /root/ 2>/dev/null 
cp /etc/skel/.profile /root/ 2>/dev/null 
chown -R root:root /root
ls -la /root/
sudo reboot
lsblk
fkdisk /dev/sdc
fdisk /dev/sdc
lsblk 
clear
lsblk 
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir -p /www_dir
mkdir -p /backup_dir
df -h | grep -E "www_dir|backupdir"
clear
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h | grep -E "www_dir|backupdir"
df -h | grep -E "www_dir|backup_dir"
blkid /dev/sdc1 /dev/sdc2
vi /etc/fstab
df -h | grep -E "www_dir|backup_dir"
mount | grep -E "www_dir|backup_dir"
chown -R www-data:www-data /www_dir/
chown -R www-data:www-data /backup_dir/
chown -R 755 /www_dir/
chown -R 755 /backup_dir/
lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINTS
cp /var/www/html/index.php /www_dir/
cp /var/www/html/logo.png /www_dir/
ls -la /www_dir/
cat /etc/fstab 
cat /etc/fstab | tail -5
umount /www_dir /backup_dir 
mount -a
mount | grep "/www_dir"
mount | grep "/backup_dir"
mkdir -p /opt/
bash -c 'cat /proc/partitions > /opt/particon'
cat /opt/particon
sed -i 's|DocumentRoot /var/www/html|DocumentRoot /www_dir|' /etc/apache2/sites-available/000-default.conf
sed -i 's|/var/www/html|/www_dir|g' /etc/apache2/.conf
sed -i 's|/var/www/html|/www_dir|g' /etc/apache2/apache2.conf 
apache2ctl  configtest
systemctl restart apache2
systemctl status apache2
bash -c 'cat /proc/partitions > /opt/particion'
mkdir -p /opt/scripts
chmod 755 /opt/scripts/
nano /opt/scripts/backup_full.sh
vi /opt/scripts/backup_full.sh
poweroff
vi /opt/scripts/backup_full.sh
mkdir -p /media/cdrom
mount /dev/cdrom /media/cdrom
apt update && apt install -y build-essential dkms linux-headers-$(uname -r)
cd /media/cdrom
sh ./VBoxLinuxAdditions.run
reboot
